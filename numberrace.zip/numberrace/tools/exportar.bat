@echo off
rem Exportador dos dados de intera��o do Number Race (evolution/pt/exportacao-dados.md).
rem Coloque este arquivo na pasta do jogo, ao lado da pasta lib (com os .jar do jogo e o sqlite-jdbc).
rem Dois cliques: exporta todas as sess�es deste computador e gera tamb�m um .zip.
rem Op��es (filtros, outras pastas, verifica��o): exportar.bat --ajuda
chcp 1252 >nul
cd /d "%~dp0"
title Number Race - exportacao dos dados
java -cp "lib\*" org.unicog.numberrace.analytics.export.ExportTool --zip %*
echo.
if "%~1"=="" if exist "%USERPROFILE%\NumberRace\v3\exportacoes" start "" "%USERPROFILE%\NumberRace\v3\exportacoes"
pause
